file name explanation:

stmo-x-y: single thread multiple outputs
x: block size
y: op_per_thread

stmvb-x-y: single thread multiple vertical blocks
x: block size
y: parallel